#ifndef PSYCHIC_H
#define PSYCHIC_H
#include "pokemon.h"

using namespace std;
class psychic : public pokemon {
  private:

  public:
     void get_capture_rate();

};

#endif
