#ifndef FLYING_H
#define FLYING_H
#include "pokemon.h"

using namespace std;
class flying : public pokemon {
  private:

  public:
     void get_capture_rate();

};

#endif
