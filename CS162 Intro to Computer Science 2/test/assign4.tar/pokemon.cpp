#include "pokemon.h"

/* Function: pokemon
 * Description: constructor for pokemon class
 * Parameters: none
 * Preconditions: none
 * Postconditions: none
 */
pokemon::pokemon() {

}

/* Function: get_capture_rate
 * Description: gets capture rate for pokemon
 * Parameters: none
 * Preconditions: none
 * Postconditions: none
 */
void pokemon::get_capture_rate() {

}

/* Function: get_event
 * Description: has get_event because pokemon is a type of event
 * Parameters: none
 * Preconditions: none
 * Postconditions: none
 */
void pokemon::get_event() {

}
