#ifndef ROCK_H
#define ROCK_H
#include "pokemon.h"

using namespace std;
class rock : public pokemon {
  private:

  public:
     void get_capture_rate();
     void catch_pokemon();


};

#endif
