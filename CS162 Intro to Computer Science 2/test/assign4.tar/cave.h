#ifndef CAVE_H
#define CAVE_H
#include "event.h"

class cave : public event {
  private:

  public:
     void get_event();

};

#endif
